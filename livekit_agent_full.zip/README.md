# LiveKit Voice Agent with Interruption Logic

This repository contains a full **LiveKit-connected voice agent** with the Intelligent Interruption Handling logic implemented.
It also includes a simulation mode so you can run and test everything locally without a LiveKit server.

## Features
- Context-aware interruption filter (ignore soft backchannels while speaking).
- VAD/STT buffering strategy: VAD triggers are validated by STT before interrupting.
- LiveKit integration (connects to a LiveKit server and subscribes to audio).
- Simulation mode: test the behavior locally (no LiveKit required).
- Modular STT and TTS components (swap providers easily).

## Quick start (simulation mode — recommended for first run)

1. Unzip the repo:
```bash
unzip livekit_agent_full.zip
cd livekit_agent_full
```

2. Create and activate a virtual environment:
```bash
python3 -m venv venv
source venv/bin/activate    # Windows: venv\\Scripts\\activate
pip install -r requirements.txt
```

3. Copy the example env and enable simulation:
```bash
cp .env.template .env
# Open .env and set USE_SIMULATION=true
```

4. Run the agent:
```bash
python main_agent.py
```

You will see a simulated "agent speaking" period and then sample transcriptions that demonstrate:
- ignoring "yeah" while speaking
- interrupting on "stop"
- responding when silent

## Quick start (LiveKit mode — real voice interaction)

1. Start a LiveKit server (local or remote). For local dev:
```bash
docker run --rm -it -p 7880:7880 -p 7881:7881 livekit/livekit-server --dev --bind 0.0.0.0
```

2. Install dependencies and copy `.env.template` to `.env`. Fill fields:
- LIVEKIT_URL (wss://... or ws://...)
- LIVEKIT_API_KEY / LIVEKIT_API_SECRET
- OPENAI_API_KEY (if you want OpenAI STT/TTS)
- USE_SIMULATION=false

3. Run:
```bash
python main_agent.py
```

Open the LiveKit demo UI (https://meet.livekit.io or your local web app), join the same room, enable mic — speak to the agent.

## Files overview
- `main_agent.py` — entrypoint; supports LiveKit and simulation modes.
- `interrupt_filter.py` — contains the core logic (ignore vs interrupt vs respond).
- `livekit_agent.py` — LiveKit connection and audio subscription (best-effort; simulation fallback).
- `stt_engine.py` — pluggable STT interface (OpenAI or simulated).
- `tts_engine.py` — pluggable TTS (pyttsx3 offline fallback).
- `.env.template` — environment variables template.
- `run.sh` — helper run script.

## Notes
- This repo aims to be pragmatic: keeps the interruption logic and integration clear.
- You might need to install system deps for microphone/audio (e.g., PortAudio).
- The LiveKit Python client API may change; the provided integration is written defensively.
